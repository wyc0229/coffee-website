# 咖啡网站自动部署脚本
# 使用PowerShell和GitHub REST API

Write-Host "🚀 开始自动部署咖啡网站到GitHub Pages" -ForegroundColor Green
Write-Host "==============================================" -ForegroundColor Cyan
Write-Host "时间: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor Gray
Write-Host ""

# GitHub配置
$GITHUB_TOKEN = "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"
$USERNAME = "wyc0229"
$REPO = "coffee-website"
$API_BASE = "https://api.github.com"

# 设置请求头
$headers = @{
    "Authorization" = "token $GITHUB_TOKEN"
    "Accept" = "application/vnd.github.v3+json"
}

function Write-Step {
    param($Step, $Message)
    Write-Host "`n==============================================" -ForegroundColor Yellow
    Write-Host "步骤 $Step : $Message" -ForegroundColor Yellow
    Write-Host "==============================================" -ForegroundColor Yellow
}

# 步骤1：检查仓库
Write-Step 1 "检查GitHub仓库"
$checkUrl = "$API_BASE/repos/$USERNAME/$REPO"
try {
    $response = Invoke-RestMethod -Uri $checkUrl -Headers $headers -Method Get
    Write-Host "✅ 仓库存在: $USERNAME/$REPO" -ForegroundColor Green
    Write-Host "   描述: $($response.description)" -ForegroundColor Gray
    Write-Host "   创建时间: $($response.created_at)" -ForegroundColor Gray
} catch {
    Write-Host "❌ 仓库检查失败: $_" -ForegroundColor Red
    Write-Host "请确保仓库已创建: https://github.com/wyc0229/coffee-website" -ForegroundColor Yellow
    Write-Host "按任意键退出..." -ForegroundColor Gray
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit 1
}

# 步骤2：上传文件
Write-Step 2 "上传网站文件"

$siteDir = "."
if (-not (Test-Path $siteDir)) {
    Write-Host "❌ 网站目录不存在: $siteDir" -ForegroundColor Red
    exit 1
}

Write-Host "上传目录: $(Resolve-Path $siteDir)" -ForegroundColor Cyan
Write-Host ""

# 上传单个文件的函数
function Upload-File {
    param($LocalPath, $RepoPath)
    
    try {
        Write-Host "  正在上传: $RepoPath" -ForegroundColor Gray -NoNewline
        
        # 读取文件内容并Base64编码
        $content = [System.IO.File]::ReadAllBytes($LocalPath)
        $encodedContent = [Convert]::ToBase64String($content)
        
        # 检查文件是否已存在
        $checkUrl = "$API_BASE/repos/$USERNAME/$REPO/contents/$RepoPath"
        $sha = $null
        try {
            $existing = Invoke-RestMethod -Uri $checkUrl -Headers $headers -Method Get
            $sha = $existing.sha
        } catch {
            # 文件不存在，正常情况
        }
        
        # 准备上传数据
        $body = @{
            message = "Add $RepoPath - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
            content = $encodedContent
        }
        
        if ($sha) {
            $body.sha = $sha
        }
        
        $jsonBody = $body | ConvertTo-Json
        
        # 上传文件
        $uploadUrl = "$API_BASE/repos/$USERNAME/$REPO/contents/$RepoPath"
        $response = Invoke-RestMethod -Uri $uploadUrl -Headers $headers -Method Put -Body $jsonBody -ContentType "application/json"
        
        Write-Host "`r  ✅ $RepoPath" -ForegroundColor Green
        return $true
    } catch {
        Write-Host "`r  ❌ $RepoPath" -ForegroundColor Red
        Write-Host "     错误详情: $($_.Exception.Message)" -ForegroundColor DarkRed
        return $false
    }
}

# 上传所有文件
$successCount = 0
$totalCount = 0

Write-Host "开始上传文件..." -ForegroundColor Cyan

# 上传根目录文件（排除部署脚本本身）
$files = Get-ChildItem -Path $siteDir -File | Where-Object {
    $_.Name -notlike "*.ps1" -and $_.Name -notlike "deploy*"
}

foreach ($file in $files) {
    $totalCount++
    if (Upload-File -LocalPath $file.FullName -RepoPath $file.Name) {
        $successCount++
    }
}

# 上传css目录
$cssDir = Join-Path $siteDir "css"
if (Test-Path $cssDir) {
    $cssFiles = Get-ChildItem -Path $cssDir -File
    foreach ($file in $cssFiles) {
        $totalCount++
        $repoPath = "css/$($file.Name)"
        if (Upload-File -LocalPath $file.FullName -RepoPath $repoPath) {
            $successCount++
        }
    }
}

# 上传js目录
$jsDir = Join-Path $siteDir "js"
if (Test-Path $jsDir) {
    $jsFiles = Get-ChildItem -Path $jsDir -File
    foreach ($file in $jsFiles) {
        $totalCount++
        $repoPath = "js/$($file.Name)"
        if (Upload-File -LocalPath $file.FullName -RepoPath $repoPath) {
            $successCount++
        }
    }
}

Write-Host "`n📊 上传统计: $successCount/$totalCount 个文件" -ForegroundColor Cyan

if ($successCount -eq 0) {
    Write-Host "❌ 所有文件上传失败，请检查令牌权限和网络连接" -ForegroundColor Red
    Write-Host "按任意键退出..." -ForegroundColor Gray
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit 1
} elseif ($successCount -lt $totalCount) {
    Write-Host "⚠️  部分文件上传失败，但继续部署..." -ForegroundColor Yellow
} else {
    Write-Host "✅ 所有文件上传成功!" -ForegroundColor Green
}

# 步骤3：启用GitHub Pages
Write-Step 3 "启用GitHub Pages"

try {
    $pagesUrl = "$API_BASE/repos/$USERNAME/$REPO/pages"
    $pagesBody = @{
        source = @{
            branch = "main"
            path = "/"
        }
    } | ConvertTo-Json
    
    $response = Invoke-RestMethod -Uri $pagesUrl -Headers $headers -Method Post -Body $pagesBody -ContentType "application/json"
    Write-Host "✅ GitHub Pages已启用" -ForegroundColor Green
    Write-Host "   分支: main" -ForegroundColor Gray
    Write-Host "   路径: / (根目录)" -ForegroundColor Gray
} catch {
    Write-Host "⚠️  启用Pages返回错误: $($_.Exception.Message)" -ForegroundColor Yellow
    Write-Host "   可能原因: Pages已启用或权限不足" -ForegroundColor Gray
    
    # 尝试获取当前状态
    try {
        $statusUrl = "$API_BASE/repos/$USERNAME/$REPO/pages"
        $status = Invoke-RestMethod -Uri $statusUrl -Headers $headers -Method Get
        Write-Host "✅ GitHub Pages当前状态: $($status.status)" -ForegroundColor Green
        if ($status.html_url) {
            Write-Host "   网站地址: $($status.html_url)" -ForegroundColor Cyan
        }
    } catch {
        Write-Host "❌ 无法获取Pages状态" -ForegroundColor Red
    }
}

# 步骤4：显示最终信息
Write-Step 4 "部署完成"

Write-Host "🎉 部署完成!" -ForegroundColor Green
Write-Host "==============================================" -ForegroundColor Cyan
Write-Host "📁 仓库地址: https://github.com/$USERNAME/$REPO" -ForegroundColor Yellow
Write-Host "🌐 网站地址: https://${USERNAME}.github.io/$REPO" -ForegroundColor Yellow
Write-Host ""

Write-Host "📋 下一步操作:" -ForegroundColor Cyan
Write-Host "1. 立即访问网站查看效果: https://wyc0229.github.io/coffee-website" -ForegroundColor White
Write-Host "2. 如果网站未显示，等待2-3分钟后刷新" -ForegroundColor White
Write-Host "3. 检查GitHub仓库的Pages状态:" -ForegroundColor White
Write-Host "   - 访问: https://github.com/wyc0229/coffee-website/settings/pages" -ForegroundColor Gray
Write-Host "   - 查看部署状态" -ForegroundColor Gray
Write-Host ""

Write-Host "🔧 测试网站功能:" -ForegroundColor Cyan
Write-Host "- 首页英雄区域是否显示" -ForegroundColor White
Write-Host "- 导航栏是否正常工作" -ForegroundColor White
Write-Host "- 响应式设计（调整浏览器大小）" -ForegroundColor White
Write-Host "- 联系表单是否可以提交" -ForegroundColor White
Write-Host ""

Write-Host "⚠️  ⚠️  ⚠️  重要安全提醒 ⚠️  ⚠️  ⚠️" -ForegroundColor Red
Write-Host "此令牌已用于上传文件，建议立即撤销:" -ForegroundColor White
Write-Host "1. 登录GitHub → Settings → Developer settings" -ForegroundColor Gray
Write-Host "2. Personal access tokens → Tokens (classic)" -ForegroundColor Gray
Write-Host "3. 找到 '咖啡网站自动部署' 令牌" -ForegroundColor Gray
Write-Host "4. 点击 'Revoke'" -ForegroundColor Gray
Write-Host "5. 下次需要时生成新令牌" -ForegroundColor Gray
Write-Host ""

Write-Host "按任意键退出..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")