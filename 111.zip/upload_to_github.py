#!/usr/bin/env python3
"""
将咖啡网站文件上传到GitHub仓库
不需要安装Git，使用GitHub API直接上传
"""

import os
import base64
import requests
import json
from pathlib import Path

def get_user_input():
    """获取用户输入"""
    print("=" * 50)
    print("GitHub 文件上传工具")
    print("=" * 50)
    
    # 仓库信息（已预设）
    username = "wyc0229"
    repo = "coffee-website"
    
    print(f"仓库: {username}/{repo}")
    print(f"仓库URL: https://github.com/{username}/{repo}")
    print()
    
    # 获取GitHub令牌
    print("需要GitHub个人访问令牌(Personal Access Token)")
    print("获取方法:")
    print("1. 登录GitHub → Settings → Developer settings")
    print("2. Personal access tokens → Tokens (classic)")
    print("3. Generate new token (classic)")
    print("4. 选择 'repo' 权限")
    print("5. 复制生成的令牌")
    print()
    
    token = input("请输入你的GitHub令牌: ").strip()
    
    return username, repo, token

def get_file_content(file_path):
    """读取文件内容并Base64编码"""
    with open(file_path, 'rb') as f:
        content = f.read()
    return base64.b64encode(content).decode('utf-8')

def upload_file(username, repo, token, file_path, repo_path):
    """上传单个文件到GitHub"""
    url = f"https://api.github.com/repos/{username}/{repo}/contents/{repo_path}"
    
    # 检查文件是否已存在
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    # 先尝试获取文件SHA（如果存在）
    sha = None
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        sha = response.json().get("sha")
    
    # 准备上传数据
    content = get_file_content(file_path)
    data = {
        "message": f"Add {repo_path}",
        "content": content
    }
    
    if sha:
        data["sha"] = sha
    
    # 上传文件
    response = requests.put(url, headers=headers, json=data)
    
    if response.status_code in [200, 201]:
        print(f"✅ 上传成功: {repo_path}")
        return True
    else:
        print(f"❌ 上传失败: {repo_path}")
        print(f"   错误: {response.status_code} - {response.text}")
        return False

def upload_directory(username, repo, token, local_dir, repo_base=""):
    """上传整个目录"""
    success_count = 0
    total_count = 0
    
    for root, dirs, files in os.walk(local_dir):
        # 计算相对路径
        rel_root = os.path.relpath(root, local_dir)
        if rel_root == ".":
            rel_root = ""
        
        for file in files:
            local_path = os.path.join(root, file)
            
            # 计算仓库中的路径
            if rel_root:
                repo_path = os.path.join(repo_base, rel_root, file).replace("\\", "/")
            else:
                repo_path = os.path.join(repo_base, file).replace("\\", "/")
            
            print(f"正在上传: {repo_path}")
            
            if upload_file(username, repo, token, local_path, repo_path):
                success_count += 1
            total_count += 1
    
    return success_count, total_count

def main():
    """主函数"""
    try:
        # 获取用户输入
        username, repo, token = get_user_input()
        
        # 设置本地目录
        script_dir = os.path.dirname(os.path.abspath(__file__))
        local_dir = script_dir  # 当前目录
        
        print()
        print("开始上传文件...")
        print("-" * 30)
        
        # 上传所有文件
        success_count = 0
        total_count = 0
        
        # 首先上传根目录文件
        for file in os.listdir(local_dir):
            file_path = os.path.join(local_dir, file)
            if os.path.isfile(file_path) and file != "upload_to_github.py":
                print(f"正在上传: {file}")
                if upload_file(username, repo, token, file_path, file):
                    success_count += 1
                total_count += 1
        
        # 上传css目录
        css_dir = os.path.join(local_dir, "css")
        if os.path.exists(css_dir):
            css_success, css_total = upload_directory(username, repo, token, css_dir, "css")
            success_count += css_success
            total_count += css_total
        
        # 上传js目录
        js_dir = os.path.join(local_dir, "js")
        if os.path.exists(js_dir):
            js_success, js_total = upload_directory(username, repo, token, js_dir, "js")
            success_count += js_success
            total_count += js_total
        
        print()
        print("=" * 50)
        print("上传完成!")
        print(f"成功: {success_count}/{total_count} 个文件")
        
        if success_count == total_count:
            print("✅ 所有文件上传成功!")
            print()
            print("下一步:")
            print("1. 访问: https://github.com/wyc0229/coffee-website")
            print("2. 点击 'Settings' → 'Pages'")
            print("3. 设置 Source: main branch, / (root)")
            print("4. 点击 'Save'")
            print("5. 等待几分钟，访问: https://wyc0229.github.io/coffee-website")
        else:
            print("⚠️  部分文件上传失败，请检查错误信息")
        
    except Exception as e:
        print(f"❌ 发生错误: {e}")
        print("请检查网络连接和令牌是否正确")
    finally:
        input("\n按Enter键退出...")

if __name__ == "__main__":
    main()