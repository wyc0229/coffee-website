// 咖啡网站交互功能

document.addEventListener('DOMContentLoaded', function() {
    // 移动端菜单切换
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            navLinks.classList.toggle('active');
            const icon = this.querySelector('i');
            if (navLinks.classList.contains('active')) {
                icon.classList.remove('fa-bars');
                icon.classList.add('fa-times');
            } else {
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            }
        });
    }
    
    // 平滑滚动
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                // 关闭移动端菜单
                if (navLinks.classList.contains('active')) {
                    navLinks.classList.remove('active');
                    const icon = menuToggle.querySelector('i');
                    icon.classList.remove('fa-times');
                    icon.classList.add('fa-bars');
                }
                
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // 导航栏滚动效果
    window.addEventListener('scroll', function() {
        const navbar = document.querySelector('.navbar');
        if (window.scrollY > 100) {
            navbar.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.1)';
            navbar.style.backgroundColor = 'rgba(255, 255, 255, 0.95)';
        } else {
            navbar.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.1)';
            navbar.style.backgroundColor = 'var(--color-white)';
        }
    });
    
    // 咖啡豆详情数据
    const beanDetails = {
        arabica: {
            name: '阿拉比卡 Arabica',
            origin: '埃塞俄比亚、巴西、哥伦比亚、危地马拉等',
            altitude: '900-2000米',
            processing: '水洗、日晒、蜜处理',
            flavorProfile: '花果香、柑橘酸、巧克力、坚果',
            characteristics: '酸度明亮，口感顺滑，香气复杂',
            bestFor: '手冲、冷萃、单品咖啡',
            score: {
                aroma: 9,
                flavor: 8.5,
                acidity: 9,
                body: 7,
                aftertaste: 8
            }
        },
        robusta: {
            name: '罗布斯塔 Robusta',
            origin: '越南、印度、印度尼西亚、乌干达等',
            altitude: '200-800米',
            processing: '日晒为主',
            flavorProfile: '坚果、巧克力、焦糖、木质香',
            characteristics: '咖啡因含量高，口感浓郁，油脂丰富',
            bestFor: '意式浓缩、拼配咖啡、速溶咖啡',
            score: {
                aroma: 7,
                flavor: 7.5,
                acidity: 5,
                body: 9,
                aftertaste: 7
            }
        },
        liberica: {
            name: '利比里卡 Liberica',
            origin: '菲律宾、马来西亚、西非',
            altitude: '200-600米',
            processing: '日晒',
            flavorProfile: '烟熏、木质香、花香、香料',
            characteristics: '豆形较大，风味独特，口感醇厚',
            bestFor: '传统冲泡、特色咖啡',
            score: {
                aroma: 8,
                flavor: 7,
                acidity: 6,
                body: 8,
                aftertaste: 8
            }
        },
        yirgacheffe: {
            name: '耶加雪菲 Yirgacheffe',
            origin: '埃塞俄比亚耶加雪菲地区',
            altitude: '1700-2200米',
            processing: '水洗、日晒',
            flavorProfile: '柑橘、茉莉花、柠檬、红茶',
            characteristics: '明亮的柑橘酸度，花香明显，茶感余韵',
            bestFor: '手冲、虹吸、冷萃',
            score: {
                aroma: 9.5,
                flavor: 9,
                acidity: 9,
                body: 7,
                aftertaste: 9
            }
        }
    };
    
    // 显示咖啡豆详情
    window.showBeanDetail = function(beanType) {
        const bean = beanDetails[beanType];
        if (!bean) return;
        
        const modalHtml = `
            <div class="modal-overlay" onclick="closeModal()">
                <div class="modal-content" onclick="event.stopPropagation()">
                    <button class="modal-close" onclick="closeModal()">
                        <i class="fas fa-times"></i>
                    </button>
                    
                    <div class="modal-header">
                        <h2>${bean.name}</h2>
                        <p class="modal-subtitle">详细品鉴信息</p>
                    </div>
                    
                    <div class="modal-body">
                        <div class="detail-grid">
                            <div class="detail-section">
                                <h3><i class="fas fa-globe-americas"></i> 产地信息</h3>
                                <p><strong>主要产区：</strong>${bean.origin}</p>
                                <p><strong>海拔高度：</strong>${bean.altitude}</p>
                                <p><strong>处理方式：</strong>${bean.processing}</p>
                            </div>
                            
                            <div class="detail-section">
                                <h3><i class="fas fa-wine-glass-alt"></i> 风味特征</h3>
                                <p><strong>风味描述：</strong>${bean.flavorProfile}</p>
                                <p><strong>特点：</strong>${bean.characteristics}</p>
                                <p><strong>适合冲泡：</strong>${bean.bestFor}</p>
                            </div>
                            
                            <div class="detail-section">
                                <h3><i class="fas fa-chart-bar"></i> 品鉴评分</h3>
                                <div class="score-chart">
                                    ${Object.entries(bean.score).map(([key, value]) => `
                                        <div class="score-item">
                                            <span>${getScoreLabel(key)}</span>
                                            <div class="score-bar">
                                                <div class="score-fill" style="width: ${value * 10}%"></div>
                                            </div>
                                            <span>${value}/10</span>
                                        </div>
                                    `).join('')}
                                </div>
                            </div>
                            
                            <div class="detail-section">
                                <h3><i class="fas fa-lightbulb"></i> 冲泡建议</h3>
                                <ul class="brewing-tips">
                                    <li>研磨粗细：${getGrindSize(beanType)}</li>
                                    <li>建议水温：${getWaterTemp(beanType)}°C</li>
                                    <li>粉水比例：${getRatio(beanType)}</li>
                                    <li>萃取时间：${getBrewTime(beanType)}</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-footer">
                        <button class="btn-primary" onclick="closeModal()">关闭</button>
                    </div>
                </div>
            </div>
        `;
        
        // 创建模态框
        const modalContainer = document.createElement('div');
        modalContainer.innerHTML = modalHtml;
        document.body.appendChild(modalContainer);
        document.body.style.overflow = 'hidden';
        
        // 添加模态框样式
        addModalStyles();
    };
    
    // 关闭模态框
    window.closeModal = function() {
        const modal = document.querySelector('.modal-overlay');
        if (modal) {
            modal.remove();
            document.body.style.overflow = 'auto';
        }
    };
    
    // 辅助函数
    function getScoreLabel(key) {
        const labels = {
            aroma: '香气',
            flavor: '风味',
            acidity: '酸度',
            body: '醇厚度',
            aftertaste: '余韵'
        };
        return labels[key] || key;
    }
    
    function getGrindSize(beanType) {
        const sizes = {
            arabica: '中细研磨',
            robusta: '中粗研磨',
            liberica: '中粗研磨',
            yirgacheffe: '中细研磨'
        };
        return sizes[beanType] || '中研磨';
    }
    
    function getWaterTemp(beanType) {
        const temps = {
            arabica: '90-92',
            robusta: '88-90',
            liberica: '88-90',
            yirgacheffe: '91-93'
        };
        return temps[beanType] || '90-92';
    }
    
    function getRatio(beanType) {
        const ratios = {
            arabica: '1:15',
            robusta: '1:12',
            liberica: '1:13',
            yirgacheffe: '1:16'
        };
        return ratios[beanType] || '1:15';
    }
    
    function getBrewTime(beanType) {
        const times = {
            arabica: '2-3分钟',
            robusta: '25-30秒',
            liberica: '3-4分钟',
            yirgacheffe: '2.5-3.5分钟'
        };
        return times[beanType] || '2-3分钟';
    }
    
    // 添加模态框样式
    function addModalStyles() {
        if (!document.querySelector('#modal-styles')) {
            const style = document.createElement('style');
            style.id = 'modal-styles';
            style.textContent = `
                .modal-overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background-color: rgba(0, 0, 0, 0.7);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    z-index: 2000;
                    padding: 20px;
                    animation: fadeIn 0.3s ease;
                }
                
                .modal-content {
                    background-color: white;
                    border-radius: 16px;
                    max-width: 800px;
                    width: 100%;
                    max-height: 90vh;
                    overflow-y: auto;
                    position: relative;
                    animation: slideUp 0.3s ease;
                }
                
                .modal-close {
                    position: absolute;
                    top: 20px;
                    right: 20px;
                    background: none;
                    border: none;
                    font-size: 1.5rem;
                    color: var(--color-gray);
                    cursor: pointer;
                    width: 40px;
                    height: 40px;
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    transition: all 0.3s ease;
                }
                
                .modal-close:hover {
                    background-color: var(--color-light-gray);
                    color: var(--color-brown);
                }
                
                .modal-header {
                    padding: 40px 40px 20px;
                    border-bottom: 1px solid var(--color-light-gray);
                }
                
                .modal-header h2 {
                    margin: 0;
                    color: var(--color-brown-dark);
                }
                
                .modal-subtitle {
                    color: var(--color-brown-light);
                    margin-top: 5px;
                }
                
                .modal-body {
                    padding: 30px 40px;
                }
                
                .detail-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                    gap: 30px;
                }
                
                .detail-section h3 {
                    display: flex;
                    align-items: center;
                    gap: 10px;
                    margin-bottom: 15px;
                    color: var(--color-brown);
                }
                
                .detail-section p {
                    margin-bottom: 10px;
                    line-height: 1.6;
                }
                
                .brewing-tips {
                    list-style: none;
                    padding: 0;
                }
                
                .brewing-tips li {
                    padding: 8px 0;
                    border-bottom: 1px solid var(--color-light-gray);
                    color: var(--color-gray);
                }
                
                .brewing-tips li:last-child {
                    border-bottom: none;
                }
                
                .score-chart {
                    margin-top: 10px;
                }
                
                .modal-footer {
                    padding: 20px 40px;
                    border-top: 1px solid var(--color-light-gray);
                    text-align: right;
                }
                
                @keyframes fadeIn {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }
                
                @keyframes slideUp {
                    from {
                        opacity: 0;
                        transform: translateY(20px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }
                
                @media (max-width: 768px) {
                    .modal-content {
                        max-height: 95vh;
                    }
                    
                    .modal-header,
                    .modal-body,
                    .modal-footer {
                        padding: 20px;
                    }
                    
                    .detail-grid {
                        grid-template-columns: 1fr;
                    }
                }
            `;
            document.head.appendChild(style);
        }
    }
    
    // 添加滚动动画
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);
    
    // 观察需要动画的元素
    document.querySelectorAll('.bean-card, .process-step, .tasting-card, .tip').forEach(el => {
        observer.observe(el);
    });
    
    // 添加动画样式
    if (!document.querySelector('#animation-styles')) {
        const style = document.createElement('style');
        style.id = 'animation-styles';
        style.textContent = `
            .bean-card,
            .process-step,
            .tasting-card,
            .tip {
                opacity: 0;
                transform: translateY(20px);
                transition: opacity 0.6s ease, transform 0.6s ease;
            }
            
            .bean-card.animate-in,
            .process-step.animate-in,
            .tasting-card.animate-in,
            .tip.animate-in {
                opacity: 1;
                transform: translateY(0);
            }
            
            .bean-card:nth-child(1) { transition-delay: 0.1s; }
            .bean-card:nth-child(2) { transition-delay: 0.2s; }
            .bean-card:nth-child(3) { transition-delay: 0.3s; }
            .bean-card:nth-child(4) { transition-delay: 0.4s; }
            
            .process-step:nth-child(1) { transition-delay: 0.1s; }
            .process-step:nth-child(2) { transition-delay: 0.2s; }
            .process-step:nth-child(3) { transition-delay: 0.3s; }
            
            .tasting-card:nth-child(1) { transition-delay: 0.1s; }
            .tasting-card:nth-child(2) { transition-delay: 0.2s; }
            .tasting-card:nth-child(3) { transition-delay: 0.3s; }
            .tasting-card:nth-child(4) { transition-delay: 0.4s; }
        `;
        document.head.appendChild(style);
    }
    
    // 联系表单提交
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // 获取表单数据
            const formData = {
                name: document.getElementById('name').value,
                email: document.getElementById('email').value,
                subject: document.getElementById('subject').value,
                message: document.getElementById('message').value
            };
            
            // 简单的表单验证
            if (!formData.name || !formData.email || !formData.message) {
                alert('请填写所有必填字段！');
                return;
            }
            
            // 显示提交成功消息
            const submitBtn = contactForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            
            submitBtn.textContent = '发送中...';
            submitBtn.disabled = true;
            
            // 模拟API调用（实际项目中应该发送到服务器）
            setTimeout(() => {
                alert('感谢您的留言！我们会尽快回复您。');
                contactForm.reset();
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
            }, 1500);
        });
    }
    
    // 导航栏添加联系我们链接
    const navLinks = document.querySelector('.nav-links');
    if (navLinks) {
        const contactLink = document.createElement('li');
        contactLink.innerHTML = '<a href="#contact"><i class="fas fa-envelope"></i> 联系我们</a>';
        navLinks.appendChild(contactLink);
    }
    
    // 咖啡豆详情功能
    const beanModal = document.getElementById('beanModal');
    const modalClose = document.querySelector('.modal-close');
    const beanDetailBtns = document.querySelectorAll('.bean-detail-btn');
    
    // 咖啡豆数据
    const beanData = {
        arabica: {
            name: "阿拉比卡 Arabica",
            icon: "fa-crown",
            badge: "精品",
            origin: "埃塞俄比亚、巴西、哥伦比亚",
            altitude: "900-2000米",
            description: "阿拉比卡咖啡豆是全球最受欢迎的品种，占世界咖啡产量的60-70%。原产于埃塞俄比亚，现在广泛种植于拉丁美洲、东非和亚洲的高海拔地区。阿拉比卡豆形较小，呈椭圆形，中间裂缝弯曲。",
            flavors: ["花果香", "柑橘酸", "巧克力", "坚果", "焦糖", "蜂蜜"],
            recommendations: [
                {
                    title: "冲泡建议",
                    content: "适合手冲、虹吸和法压壶。水温92-96°C，粉水比1:15-1:18，萃取时间2-3分钟。"
                },
                {
                    title: "烘焙程度",
                    content: "浅焙至中焙最能展现其花果香气和明亮酸质。深焙会损失部分风味特性。"
                },
                {
                    title: "品鉴要点",
                    content: "关注其复杂的香气层次、明亮的酸度和干净的余韵。优质阿拉比卡应有持久的甜感。"
                },
                {
                    title: "搭配建议",
                    content: "搭配水果塔、芝士蛋糕或黑巧克力，能增强咖啡的果酸和甜感。"
                }
            ]
        },
        robusta: {
            name: "罗布斯塔 Robusta",
            icon: "fa-bolt",
            badge: "浓郁",
            origin: "越南、印度、印度尼西亚",
            altitude: "200-800米",
            description: "罗布斯塔咖啡豆咖啡因含量较高（约2.7%），是阿拉比卡的两倍。原产于非洲中部和西部，现在主要种植在东南亚和非洲。豆形较圆，中间裂缝较直。",
            flavors: ["坚果", "巧克力", "焦糖", "木质香", "麦芽", "香料"],
            recommendations: [
                {
                    title: "冲泡建议",
                    content: "适合意式浓缩、摩卡壶。水温88-92°C，粉水比1:12-1:15，可承受更高压力萃取。"
                },
                {
                    title: "烘焙程度",
                    content: "中焙至深焙，能增强其醇厚度和巧克力风味，减少苦味。"
                },
                {
                    title: "品鉴要点",
                    content: "关注其醇厚度、crema（油脂）质量和持久的余韵。优质罗布斯塔应有丰富的口感。"
                },
                {
                    title: "搭配建议",
                    content: "搭配牛奶巧克力、坚果饼干或焦糖布丁，能平衡其浓郁口感。"
                }
            ]
        },
        liberica: {
            name: "利比里卡 Liberica",
            icon: "fa-gem",
            badge: "稀有",
            origin: "菲律宾、马来西亚",
            altitude: "200-600米",
            description: "利比里卡咖啡豆是三大原生种中最稀有的，仅占全球产量不到2%。豆形最大，呈不对称椭圆形，有独特的香气和风味。在19世纪咖啡锈病危机后，成为菲律宾的主要品种。",
            flavors: ["烟熏", "木质香", "花香", "香料", "果香", "坚果"],
            recommendations: [
                {
                    title: "冲泡建议",
                    content: "适合法压壶、虹吸壶。水温90-94°C，粉水比1:14-1:16，需要充分萃取以展现复杂风味。"
                },
                {
                    title: "烘焙程度",
                    content: "中焙最佳，能平衡其烟熏感和花果香气，避免过度烘焙掩盖独特风味。"
                },
                {
                    title: "品鉴要点",
                    content: "关注其独特的烟熏木质香气、醇厚口感和持久的香料余韵。"
                },
                {
                    title: "搭配建议",
                    content: "搭配烟熏肉类、芝士拼盘或香料蛋糕，能增强其独特的风味特性。"
                }
            ]
        },
        yirgacheffe: {
            name: "耶加雪菲 Yirgacheffe",
            icon: "fa-star",
            badge: "特选",
            origin: "埃塞俄比亚",
            altitude: "1700-2200米",
            description: "耶加雪菲是埃塞俄比亚最著名的咖啡产区，以其独特的处理方式和卓越的品质闻名。采用水洗处理法，咖啡豆带有明亮的柑橘酸度和茉莉花香，被誉为'咖啡中的香槟'。",
            flavors: ["柑橘", "茉莉花", "柠檬", "红茶", "蜂蜜", "杏桃"],
            recommendations: [
                {
                    title: "冲泡建议",
                    content: "必须使用手冲或虹吸壶。水温90-92°C，粉水比1:16-1:18，轻柔注水以保留细腻香气。"
                },
                {
                    title: "烘焙程度",
                    content: "浅焙至中浅焙，能最大程度保留其花果香气和明亮酸质。"
                },
                {
                    title: "品鉴要点",
                    content: "关注其优雅的花香、明亮的柑橘酸度和茶感余韵。优质耶加雪菲应有持久的甜感。"
                },
                {
                    title: "搭配建议",
                    content: "搭配柠檬塔、水果沙拉或轻乳酪蛋糕，能增强其清新口感。"
                }
            ]
        },
        colombia: {
            name: "哥伦比亚苏普雷莫",
            icon: "fa-mountain",
            badge: "平衡",
            origin: "哥伦比亚",
            altitude: "1200-1800米",
            description: "哥伦比亚是全球最大的阿拉比卡咖啡生产国之一，苏普雷莫是最高等级。哥伦比亚咖啡以平衡的口感著称，酸度、甜度和醇厚度完美结合，适合大多数咖啡爱好者。",
            flavors: ["坚果", "巧克力", "焦糖", "柑橘", "香料", "蜂蜜"],
            recommendations: [
                {
                    title: "冲泡建议",
                    content: "适合各种冲泡方式。水温92-94°C，粉水比1:15，萃取时间2-2.5分钟。"
                },
                {
                    title: "烘焙程度",
                    content: "中焙最佳，能展现其平衡的风味特性，既有酸度又有甜感。"
                },
                {
                    title: "品鉴要点",
                    content: "关注其平衡的口感、干净的余韵和持久的甜感。优质哥伦比亚应有丰富的层次。"
                },
                {
                    title: "搭配建议",
                    content: "搭配牛奶巧克力、坚果面包或焦糖布丁，能增强其甜感和醇厚度。"
                }
            ]
        },
        kenya: {
            name: "肯尼亚AA",
            icon: "fa-wine-glass-alt",
            badge: "果酸",
            origin: "肯尼亚",
            altitude: "1500-2100米",
            description: "肯尼亚AA是最高等级的肯尼亚咖啡，采用独特的双重水洗处理法。以其明亮的莓果酸质和葡萄酒般的口感著称，带有黑醋栗、番茄和香料的风味层次。",
            flavors: ["莓果", "黑醋栗", "番茄", "香料", "柠檬", "红糖"],
            recommendations: [
                {
                    title: "冲泡建议",
                    content: "适合手冲和虹吸壶。水温93-95°C，粉水比1:16，需要充分萃取以展现复杂酸质。"
                },
                {
                    title: "烘焙程度",
                    content: "中焙，能平衡其明亮的酸度和丰富的甜感，避免过度烘焙。"
                },
                {
                    title: "品鉴要点",
                    content: "关注其葡萄酒般的酸质、丰富的莓果风味和持久的香料余韵。"
                },
                {
                    title: "搭配建议",
                    content: "搭配莓果派、番茄奶酪或香料饼干，能增强其果酸和香料风味。"
                }
            ]
        },
        guatemala: {
            name: "危地马拉安提瓜",
            icon: "fa-volcano",
            badge: "火山",
            origin: "危地马拉",
            altitude: "1500-1700米",
            description: "安提瓜是危地马拉最著名的咖啡产区，位于三座火山之间。火山土壤富含矿物质，赋予咖啡独特的烟熏、巧克力和香料风味，口感醇厚，酸度柔和。",
            flavors: ["烟熏", "巧克力", "香料", "焦糖", "坚果", "柑橘"],
            recommendations: [
                {
                    title: "冲泡建议",
                    content: "适合法压壶、摩卡壶。水温90-92°C，粉水比1:14，充分萃取以展现醇厚度。"
                },
                {
                    title: "烘焙程度",
                    content: "中焙至深焙，能增强其烟熏感和巧克力风味，平衡酸度。"
                },
                {
                    title: "品鉴要点",
                    content: "关注其独特的烟熏香气、醇厚口感和持久的巧克力余韵。"
                },
                {
                    title: "搭配建议",
                    content: "搭配黑巧克力、坚果蛋糕或烟熏肉类，能增强其浓郁口感。"
                }
            ]
        },
        kona: {
            name: "夏威夷科纳",
            icon: "fa-umbrella-beach",
            badge: "奢华",
            origin: "美国夏威夷",
            altitude: "600-900米",
            description: "科纳咖啡产自夏威夷大岛的科纳地区，产量稀少，价格昂贵。独特的火山土壤和海洋气候赋予咖啡顺滑的口感和丰富的风味层次，带有坚果、香料和热带水果的甜感。",
            flavors: ["坚果", "香料", "热带水果", "蜂蜜", "焦糖", "香草"],
            recommendations: [
                {
                    title: "冲泡建议",
                    content: "适合手冲和虹吸壶。水温88-90°C，粉水比1:17，轻柔萃取以保留细腻风味。"
                },
                {
                    title: "烘焙程度",
                    content: "中焙，能展现其丰富的风味层次和顺滑口感，避免过度烘焙。"
                },
                {
                    title: "品鉴要点",
                    content: "关注其顺滑的口感、丰富的风味层次和持久的甜感余韵。"
                },
                {
                    title: "搭配建议",
                    content: "搭配热带水果沙拉、椰子蛋糕或香草冰淇淋，能增强其甜感和顺滑度。"
                }
            ]
        }
    };
    
    // 打开模态框
    function openBeanModal(beanId) {
        const bean = beanData[beanId];
        if (!bean) return;
        
        const container = document.querySelector('.bean-detail-container');
        
        // 构建HTML内容
        container.innerHTML = `
            <div class="bean-detail-image">
                <i class="fas ${bean.icon}"></i>
            </div>
            <div class="bean-detail-info">
                <h3>${bean.name}</h3>
                <div class="bean-detail-meta">
                    <div class="meta-item">
                        <i class="fas fa-globe-americas"></i>
                        <span>产地: ${bean.origin}</span>
                    </div>
                    <div class="meta-item">
                        <i class="fas fa-mountain"></i>
                        <span>海拔: ${bean.altitude}</span>
                    </div>
                    <div class="meta-item">
                        <i class="fas fa-tag"></i>
                        <span>等级: ${bean.badge}</span>
                    </div>
                </div>
                <p class="bean-detail-description">${bean.description}</p>
                <div class="bean-detail-flavors">
                    ${bean.flavors.map(flavor => `<span class="flavor-tag-large">${flavor}</span>`).join('')}
                </div>
            </div>
            <div class="tasting-recommendations">
                <h4><i class="fas fa-lightbulb"></i> 品鉴建议</h4>
                <div class="recommendation-grid">
                    ${bean.recommendations.map(rec => `
                        <div class="recommendation-item">
                            <h5>${rec.title}</h5>
                            <p>${rec.content}</p>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
        
        // 显示模态框
        beanModal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    }
    
    // 关闭模态框
    function closeBeanModal() {
        beanModal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
    
    // 绑定事件
    if (modalClose) {
        modalClose.addEventListener('click', closeBeanModal);
    }
    
    // 点击模态框背景关闭
    beanModal.addEventListener('click', function(e) {
        if (e.target === beanModal) {
            closeBeanModal();
        }
    });
    
    // 绑定咖啡豆详情按钮
    beanDetailBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const beanCard = this.closest('.bean-card');
            const beanId = beanCard.getAttribute('data-bean');
            openBeanModal(beanId);
        });
    });
    
    // ESC键关闭模态框
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && beanModal.style.display === 'block') {
            closeBeanModal();
        }
    });
    
    // 咖啡种植小游戏逻辑
    const gameState = {
        coins: 100,
        beans: 0,
        coupons: 0,
        level: 1,
        plantStage: 'seed', // seed, seedling, flower, fruit
        growthProgress: 0,
        waterLevel: 50,
        nutrientLevel: 50,
        hasPlant: true,
        growthInterval: null
    };
    
    // 商店商品数据
    const storeProducts = {
        arabica: {
            name: "精品阿拉比卡咖啡豆",
            desc: "来自埃塞俄比亚的精品咖啡豆，带有花果香气和明亮的柑橘酸度。",
            image: "https://images.unsplash.com/photo-1587734195507-6f5e8a2543c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
            originalPrice: "¥128",
            discountPrice: "¥98",
            couponCost: 1
        },
        robusta: {
            name: "浓郁罗布斯塔咖啡豆",
            desc: "越南产罗布斯塔豆，口感浓郁醇厚，带有坚果和巧克力风味。",
            image: "https://images.unsplash.com/photo-1511537190424-bbbab87ac5eb?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
            originalPrice: "¥98",
            discountPrice: "¥78",
            couponCost: 1
        },
        giftbox: {
            name: "精品咖啡体验礼盒",
            desc: "包含3种不同产地的精品咖啡豆和手冲壶套装，完美咖啡体验。",
            image: "https://images.unsplash.com/photo-1510707577719-ae7c9b788690?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
            originalPrice: "¥298",
            discountPrice: "¥228",
            couponCost: 2
        }
    };
    
    // 更新UI显示
    function updateGameUI() {
        // 更新统计数据
        document.getElementById('coinCount').textContent = gameState.coins;
        document.getElementById('beanCount').textContent = gameState.beans;
        document.getElementById('couponCount').textContent = gameState.coupons;
        document.getElementById('levelCount').textContent = gameState.level;
        
        // 更新植物状态
        const plantStage = document.getElementById('plantStage');
        const plantImg = document.getElementById('plantImg');
        const plantStatus = document.getElementById('plantStatus');
        
        // 更新图片和状态
        let stageText = '种子';
        let stageImage = 'https://images.unsplash.com/photo-1510707577719-ae7c9b788690?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80';
        let statusText = '咖啡种子';
        
        switch(gameState.plantStage) {
            case 'seedling':
                stageText = '幼苗';
                stageImage = 'https://images.unsplash.com/photo-1510707577719-ae7c9b788690?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80';
                statusText = '咖啡幼苗';
                break;
            case 'flower':
                stageText = '开花';
                stageImage = 'https://images.unsplash.com/photo-1510707577719-ae7c9b788690?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80';
                statusText = '咖啡花';
                break;
            case 'fruit':
                stageText = '结果';
                stageImage = 'https://images.unsplash.com/photo-1510707577719-ae7c9b788690?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80';
                statusText = '咖啡果实';
                break;
        }
        
        plantStage.innerHTML = `<span class="stage-badge">${stageText}</span>`;
        plantImg.src = stageImage;
        plantImg.alt = statusText;
        plantStatus.textContent = statusText;
        
        // 更新进度条
        document.getElementById('growthProgress').style.width = `${gameState.growthProgress}%`;
        
        // 更新水分和营养
        document.getElementById('waterLevel').textContent = gameState.waterLevel;
        document.getElementById('nutrientLevel').textContent = gameState.nutrientLevel;
        
        // 更新按钮状态
        const harvestBtn = document.getElementById('harvestBtn');
        const sellBtn = document.getElementById('sellBtn');
        
        harvestBtn.disabled = gameState.plantStage !== 'fruit';
        sellBtn.disabled = gameState.beans === 0;
        
        // 更新商店按钮状态
        updateShopButtons();
        
        // 更新优惠券进度
        updateCouponProgress();
        
        // 检查是否升级
        checkLevelUp();
    }
    
    // 更新优惠券进度
    function updateCouponProgress() {
        const progress = (gameState.beans % 50) / 50 * 100;
        document.getElementById('couponProgress').style.width = `${progress}%`;
        document.getElementById('couponProgressText').textContent = `${gameState.beans % 50}/50`;
        
        // 更新兑换按钮状态
        const exchangeBtn = document.getElementById('exchangeCouponBtn');
        exchangeBtn.disabled = gameState.beans < 50;
    }
    
    // 更新商店按钮状态
    function updateShopButtons() {
        const seedBtn = document.querySelector('.buy-seed-btn');
        const fertilizerBtn = document.querySelector('.buy-fertilizer-btn');
        const hormoneBtn = document.querySelector('.buy-hormone-btn');
        
        seedBtn.disabled = gameState.coins < 30 || gameState.hasPlant;
        fertilizerBtn.disabled = gameState.coins < 25 || !gameState.hasPlant;
        hormoneBtn.disabled = gameState.coins < 50 || !gameState.hasPlant || gameState.plantStage === 'fruit';
    }
    
    // 检查升级
    function checkLevelUp() {
        const oldLevel = gameState.level;
        if (gameState.coins >= 500 && gameState.level < 2) {
            gameState.level = 2;
        } else if (gameState.coins >= 1000 && gameState.level < 3) {
            gameState.level = 3;
        } else if (gameState.coins >= 2000 && gameState.level < 4) {
            gameState.level = 4;
        } else if (gameState.coins >= 5000 && gameState.level < 5) {
            gameState.level = 5;
        }
        
        if (gameState.level > oldLevel) {
            showGameMessage(`恭喜升级到 ${gameState.level} 级！`, 'success');
        }
    }
    
    // 显示游戏消息
    function showGameMessage(message, type = 'info') {
        // 创建消息元素
        const messageEl = document.createElement('div');
        messageEl.className = `game-message game-message-${type}`;
        messageEl.textContent = message;
        messageEl.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            background: ${type === 'success' ? '#4caf50' : type === 'error' ? '#f44336' : '#2196f3'};
            color: white;
            border-radius: 5px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 10000;
            animation: slideIn 0.3s ease;
        `;
        
        document.body.appendChild(messageEl);
        
        // 3秒后移除
        setTimeout(() => {
            messageEl.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => {
                if (messageEl.parentNode) {
                    messageEl.parentNode.removeChild(messageEl);
                }
            }, 300);
        }, 3000);
    }
    
    // 添加CSS动画
    if (!document.querySelector('#game-animations')) {
        const style = document.createElement('style');
        style.id = 'game-animations';
        style.textContent = `
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            @keyframes slideOut {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
            @keyframes bounce {
                0%, 100% { transform: scale(1); }
                50% { transform: scale(1.1); }
            }
        `;
        document.head.appendChild(style);
    }
    
    // 浇水功能
    function waterPlant() {
        if (gameState.coins < 5) {
            showGameMessage('金币不足！', 'error');
            return;
        }
        
        if (!gameState.hasPlant) {
            showGameMessage('请先购买种子！', 'error');
            return;
        }
        
        gameState.coins -= 5;
        gameState.waterLevel = Math.min(100, gameState.waterLevel + 15);
        
        // 浇水动画
        const plantStage = document.getElementById('plantStage');
        plantStage.style.animation = 'bounce 0.5s ease';
        setTimeout(() => {
            plantStage.style.animation = '';
        }, 500);
        
        showGameMessage('浇水成功！水分+15', 'success');
        updateGameUI();
    }
    
    // 施肥功能
    function fertilizePlant() {
        if (gameState.coins < 10) {
            showGameMessage('金币不足！', 'error');
            return;
        }
        
        if (!gameState.hasPlant) {
            showGameMessage('请先购买种子！', 'error');
            return;
        }
        
        gameState.coins -= 10;
        gameState.nutrientLevel = Math.min(100, gameState.nutrientLevel + 20);
        
        showGameMessage('施肥成功！营养+20', 'success');
        updateGameUI();
    }
    
    // 收获功能
    function harvestPlant() {
        if (gameState.plantStage !== 'fruit') {
            showGameMessage('咖啡豆还未成熟！', 'error');
            return;
        }
        
        // 计算收获数量（基于植物健康度）
        const healthBonus = Math.floor((gameState.waterLevel + gameState.nutrientLevel) / 20);
        const beansHarvested = 10 + healthBonus;
        
        gameState.beans += beansHarvested;
        
        // 检查是否可以兑换优惠券
        checkCouponExchange();
        
        // 重置植物
        resetPlant();
        
        showGameMessage(`收获成功！获得 ${beansHarvested} 个咖啡豆`, 'success');
        updateGameUI();
    }
    
    // 检查并兑换优惠券
    function checkCouponExchange() {
        if (gameState.beans >= 50) {
            showGameMessage('已收集50个咖啡豆，可以兑换优惠券了！', 'success');
        }
    }
    
    // 兑换优惠券
    function exchangeCoupon() {
        if (gameState.beans < 50) {
            showGameMessage('需要50个咖啡豆才能兑换优惠券！', 'error');
            return;
        }
        
        gameState.beans -= 50;
        gameState.coupons += 1;
        
        showGameMessage('兑换成功！获得1张优惠券', 'success');
        updateGameUI();
    }
    
    // 出售功能
    function sellBeans() {
        if (gameState.beans === 0) {
            showGameMessage('没有咖啡豆可出售！', 'error');
            return;
        }
        
        const coinsEarned = gameState.beans * 2;
        gameState.coins += coinsEarned;
        gameState.beans = 0;
        
        showGameMessage(`出售成功！获得 ${coinsEarned} 金币`, 'success');
        updateGameUI();
    }
    
    // 购买种子
    function buySeed() {
        if (gameState.coins < 30) {
            showGameMessage('金币不足！', 'error');
            return;
        }
        
        if (gameState.hasPlant) {
            showGameMessage('已经有植物了！', 'error');
            return;
        }
        
        gameState.coins -= 30;
        gameState.hasPlant = true;
        resetPlant();
        
        showGameMessage('购买种子成功！开始种植吧', 'success');
        updateGameUI();
        startGrowthTimer();
    }
    
    // 购买肥料
    function buyFertilizer() {
        if (gameState.coins < 25) {
            showGameMessage('金币不足！', 'error');
            return;
        }
        
        if (!gameState.hasPlant) {
            showGameMessage('请先购买种子！', 'error');
            return;
        }
        
        gameState.coins -= 25;
        gameState.nutrientLevel = Math.min(100, gameState.nutrientLevel + 15);
        
        showGameMessage('购买肥料成功！营养+15', 'success');
        updateGameUI();
    }
    
    // 购买生长激素
    function buyGrowthHormone() {
        if (gameState.coins < 50) {
            showGameMessage('金币不足！', 'error');
            return;
        }
        
        if (!gameState.hasPlant) {
            showGameMessage('请先购买种子！', 'error');
            return;
        }
        
        if (gameState.plantStage === 'fruit') {
            showGameMessage('植物已经成熟了！', 'error');
            return;
        }
        
        gameState.coins -= 50;
        
        // 推进到下一阶段
        const stages = ['seed', 'seedling', 'flower', 'fruit'];
        const currentIndex = stages.indexOf(gameState.plantStage);
        if (currentIndex < stages.length - 1) {
            gameState.plantStage = stages[currentIndex + 1];
            gameState.growthProgress = 0;
        }
        
        showGameMessage('使用生长激素成功！植物快速生长', 'success');
        updateGameUI();
    }
    
    // 购买商品功能
    function openPurchaseModal(productId) {
        const product = storeProducts[productId];
        if (!product) return;
        
        // 更新模态框内容
        document.getElementById('purchaseItemImage').src = product.image;
        document.getElementById('purchaseItemImage').alt = product.name;
        document.getElementById('purchaseItemName').textContent = product.name;
        document.getElementById('purchaseItemDesc').textContent = product.desc;
        document.getElementById('purchaseItemPrice').innerHTML = `
            <span style="text-decoration: line-through; color: var(--color-gray); margin-right: 10px;">${product.originalPrice}</span>
            <span style="color: var(--color-brown); font-weight: 700;">${product.discountPrice}</span>
        `;
        document.getElementById('purchaseCouponCost').textContent = product.couponCost;
        
        // 更新确认按钮状态
        const confirmBtn = document.getElementById('purchaseConfirmBtn');
        confirmBtn.disabled = gameState.coupons < product.couponCost;
        confirmBtn.dataset.productId = productId;
        
        // 显示模态框
        document.getElementById('purchaseModal').style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
    
    // 确认购买
    function confirmPurchase() {
        const confirmBtn = document.getElementById('purchaseConfirmBtn');
        const productId = confirmBtn.dataset.productId;
        const product = storeProducts[productId];
        
        if (!product) return;
        
        if (gameState.coupons < product.couponCost) {
            showGameMessage('优惠券不足！', 'error');
            return;
        }
        
        // 扣除优惠券
        gameState.coupons -= product.couponCost;
        
        // 关闭模态框
        closePurchaseModal();
        
        // 显示购买成功消息
        showGameMessage(`购买成功！已使用${product.couponCost}张优惠券购买"${product.name}"`, 'success');
        
        // 生成模拟订单
        generateMockOrder(product);
        
        updateGameUI();
    }
    
    // 生成模拟订单
    function generateMockOrder(product) {
        const orderId = 'ORD' + Date.now().toString().slice(-8);
        const orderDate = new Date().toLocaleString('zh-CN');
        
        const orderDetails = `
            <div style="background: #f5f5f5; padding: 20px; border-radius: 10px; margin-top: 20px;">
                <h4 style="color: var(--color-brown-dark); margin-bottom: 10px;">📦 模拟订单已生成</h4>
                <p style="margin: 5px 0;"><strong>订单号：</strong>${orderId}</p>
                <p style="margin: 5px 0;"><strong>商品：</strong>${product.name}</p>
                <p style="margin: 5px 0;"><strong>价格：</strong>${product.discountPrice}</p>
                <p style="margin: 5px 0;"><strong>下单时间：</strong>${orderDate}</p>
                <p style="margin: 5px 0;"><strong>状态：</strong><span style="color: #4caf50;">待发货</span></p>
                <p style="margin-top: 10px; font-size: 0.9em; color: #666;">注：此为模拟订单，实际购买需跳转至电商平台</p>
            </div>
        `;
        
        // 显示订单详情
        setTimeout(() => {
            showGameMessageWithHTML(`🎉 购买成功！${orderDetails}`, 'success', 8000);
        }, 500);
    }
    
    // 显示带HTML的消息
    function showGameMessageWithHTML(html, type = 'info', duration = 3000) {
        const messageEl = document.createElement('div');
        messageEl.className = `game-message game-message-${type}`;
        messageEl.innerHTML = html;
        messageEl.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 20px;
            background: ${type === 'success' ? '#4caf50' : type === 'error' ? '#f44336' : '#2196f3'};
            color: white;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 10000;
            animation: slideIn 0.3s ease;
            max-width: 400px;
        `;
        
        document.body.appendChild(messageEl);
        
        setTimeout(() => {
            messageEl.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => {
                if (messageEl.parentNode) {
                    messageEl.parentNode.removeChild(messageEl);
                }
            }, 300);
        }, duration);
    }
    
    // 关闭购买模态框
    function closePurchaseModal() {
        document.getElementById('purchaseModal').style.display = 'none';
        document.body.style.overflow = 'auto';
    }
    
    // 重置植物
    function resetPlant() {
        gameState.plantStage = 'seed';
        gameState.growthProgress = 0;
        gameState.waterLevel = 50;
        gameState.nutrientLevel = 50;
    }
    
    // 开始生长计时器
    function startGrowthTimer() {
        if (gameState.growthInterval) {
            clearInterval(gameState.growthInterval);
        }
        
        gameState.growthInterval = setInterval(() => {
            if (!gameState.hasPlant) return;
            
            // 计算生长速度（基于水分和营养）
            const growthRate = 1 + (gameState.waterLevel + gameState.nutrientLevel - 100) / 100;
            
            gameState.growthProgress += growthRate;
            
            // 减少水分和营养
            gameState.waterLevel = Math.max(0, gameState.waterLevel - 0.5);
            gameState.nutrientLevel = Math.max(0, gameState.nutrientLevel - 0.3);
            
            // 检查阶段变化
            if (gameState.growthProgress >= 100) {
                gameState.growthProgress = 0;
                
                const stages = ['seed', 'seedling', 'flower', 'fruit'];
                const currentIndex = stages.indexOf(gameState.plantStage);
                
                if (currentIndex < stages.length - 1) {
                    gameState.plantStage = stages[currentIndex + 1];
                    showGameMessage(`植物进入 ${gameState.plantStage === 'seedling' ? '幼苗' : gameState.plantStage === 'flower' ? '开花' : '结果'} 阶段！`, 'success');
                }
            }
            
            updateGameUI();
            
            // 检查植物死亡
            if (gameState.waterLevel <= 0 || gameState.nutrientLevel <= 0) {
                clearInterval(gameState.growthInterval);
                gameState.hasPlant = false;
                showGameMessage('植物枯萎了！请重新购买种子', 'error');
                updateGameUI();
            }
            
        }, 1000); // 每秒更新一次
    }
    
    // 绑定游戏按钮事件
    document.getElementById('waterBtn').addEventListener('click', waterPlant);
    document.getElementById('fertilizeBtn').addEventListener('click', fertilizePlant);
    document.getElementById('harvestBtn').addEventListener('click', harvestPlant);
    document.getElementById('sellBtn').addEventListener('click', sellBeans);
    
    document.querySelector('.buy-seed-btn').addEventListener('click', buySeed);
    document.querySelector('.buy-fertilizer-btn').addEventListener('click', buyFertilizer);
    document.querySelector('.buy-hormone-btn').addEventListener('click', buyGrowthHormone);
    
    // 绑定优惠券和购买事件
    document.getElementById('exchangeCouponBtn').addEventListener('click', exchangeCoupon);
    
    // 绑定购买按钮事件
    document.querySelectorAll('.buy-product-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const productId = this.dataset.product;
            openPurchaseModal(productId);
        });
    });
    
    // 绑定购买模态框事件
    document.getElementById('purchaseConfirmBtn').addEventListener('click', confirmPurchase);
    document.querySelector('.purchase-modal-close').addEventListener('click', closePurchaseModal);
    
    // 点击模态框背景关闭
    document.getElementById('purchaseModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closePurchaseModal();
        }
    });
    
    // ESC键关闭购买模态框
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && document.getElementById('purchaseModal').style.display === 'flex') {
            closePurchaseModal();
        }
    });
    
    // 初始化游戏
    updateGameUI();
    startGrowthTimer();
    
    // 导航栏添加游戏链接
    if (navLinks) {
        const gameLink = document.createElement('li');
        gameLink.innerHTML = '<a href="#game"><i class="fas fa-gamepad"></i> 小游戏</a>';
        navLinks.appendChild(gameLink);
    }
});