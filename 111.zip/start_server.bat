@echo off
echo 启动咖啡网站本地服务器...
echo.

REM 检查Python是否安装
python --version >nul 2>&1
if errorlevel 1 (
    echo 错误: 未找到Python，请先安装Python 3.x
    echo 可以从 https://python.org 下载
    pause
    exit /b 1
)

REM 启动服务器
echo 正在启动服务器...
echo 按 Ctrl+C 停止服务器
echo.
python server.py

if errorlevel 1 (
    echo.
    echo 启动失败，请检查错误信息
    pause
)