# 咖啡品鉴指南网站

一个响应式的咖啡知识网站，展示咖啡豆品种、制作工艺、品鉴方法和专业工具。

## 功能特点

- ✅ 响应式设计，适配所有设备
- ✅ 平滑滚动导航
- ✅ 交互式咖啡豆详情展示
- ✅ 咖啡工具介绍
- ✅ 联系表单（模拟提交）
- ✅ 移动端友好菜单
- ✅ 滚动动画效果

## 文件结构

```
coffee_website/
├── index.html          # 主页面
├── css/
│   └── style.css      # 样式文件
├── js/
│   └── script.js      # JavaScript交互
├── server.py          # Python本地服务器
├── start_server.bat   # Windows启动脚本
└── README.md          # 说明文档
```

## 快速开始

### 方法1：使用Python本地服务器（推荐）

1. 确保已安装Python 3.x
2. 在命令行中进入网站目录：
   ```bash
   cd coffee_website
   ```
3. 运行启动脚本：
   - Windows: 双击 `start_server.bat`
   - 或手动运行：`python server.py`
4. 浏览器会自动打开 http://localhost:8000

### 方法2：直接打开文件

直接双击 `index.html` 文件在浏览器中打开。

## 部署到GitHub Pages

1. 在GitHub上创建新仓库
2. 将网站文件上传到仓库
3. 进入仓库设置 → Pages
4. 选择分支（通常是main）和根目录
5. 保存后访问 `https://你的用户名.github.io/仓库名`

## 网站内容

### 主要部分

1. **首页** - 欢迎区域和简介
2. **咖啡豆品种** - 介绍阿拉比卡、罗布斯塔等
3. **制作工艺** - 手冲、冷萃、意式等方法
4. **品鉴指南** - 视觉、嗅觉、味觉评估
5. **咖啡工具** - 专业工具介绍
6. **联系我们** - 联系信息和表单

### 技术特性

- 使用CSS变量统一配色
- Flexbox和Grid布局
- 移动端优先设计
- 渐进增强的JavaScript功能
- 无障碍设计考虑

## 自定义修改

### 修改配色

在 `css/style.css` 中修改CSS变量：
```css
:root {
    --color-brown: #5d4037;
    --color-brown-light: #8d6e63;
    --color-accent: #795548;
}
```

### 添加新内容

在 `index.html` 中添加新的section，并在CSS和JS中添加相应样式和功能。

## 浏览器支持

- Chrome 60+
- Firefox 55+
- Safari 10+
- Edge 79+

## 许可证

MIT License - 自由使用和修改