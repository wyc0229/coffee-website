# 部署到GitHub Pages指南

## 步骤1：在GitHub创建仓库

1. 登录GitHub
2. 点击右上角 "+" → "New repository"
3. 填写仓库信息：
   - Repository name: `coffee-website` (或其他名称)
   - Description: "咖啡品鉴指南网站"
   - 选择 Public
   - 不要初始化README（我们已有文件）
4. 点击 "Create repository"

## 步骤2：准备本地Git

如果你还没有安装Git：
1. 下载Git: https://git-scm.com/downloads
2. 安装Git

## 步骤3：初始化Git仓库

在命令行中进入网站目录：

```bash
cd coffee_website
```

初始化Git：

```bash
git init
git add .
git commit -m "Initial commit: 咖啡网站"
```

## 步骤4：连接到GitHub仓库

复制GitHub仓库的URL（格式：`https://github.com/你的用户名/仓库名.git`）

```bash
git remote add origin https://github.com/你的用户名/coffee-website.git
git branch -M main
git push -u origin main
```

## 步骤5：启用GitHub Pages

1. 在GitHub仓库页面，点击 "Settings"
2. 左侧菜单选择 "Pages"
3. 在 "Source" 部分：
   - Branch: 选择 `main`
   - Folder: 选择 `/ (root)`
4. 点击 "Save"

## 步骤6：等待部署

GitHub Pages 需要几分钟部署。部署完成后，你会看到：
- 绿色勾号表示部署成功
- 你的网站地址：`https://你的用户名.github.io/coffee-website`

## 步骤7：更新网站

如果你修改了网站，推送更新：

```bash
git add .
git commit -m "更新描述"
git push
```

GitHub会自动重新部署。

## 常见问题

### 1. 网站不显示样式
确保所有文件路径正确，GitHub Pages需要相对路径。

### 2. 404错误
- 检查仓库名称是否正确
- 确保 `index.html` 在根目录
- 等待几分钟让GitHub完成部署

### 3. 自定义域名
在GitHub Pages设置中添加自定义域名。

## 优化建议

### 1. 压缩图片
如果添加图片，先压缩以加快加载速度。

### 2. 添加favicon
在 `index.html` 的 `<head>` 中添加：
```html
<link rel="icon" href="favicon.ico" type="image/x-icon">
```

### 3. 添加SEO元标签
```html
<meta name="description" content="咖啡品鉴指南，了解咖啡豆品种、制作工艺和品鉴方法">
<meta name="keywords" content="咖啡,品鉴,手冲,咖啡豆,制作工艺">
```

## 替代方案：Netlify

如果你想要更快的部署和更多功能，可以使用Netlify：

1. 注册 Netlify: https://netlify.com
2. 拖放 `coffee_website` 文件夹到Netlify
3. 自动获得一个 `*.netlify.app` 域名
4. 支持自动部署、HTTPS等

## 技术支持

如果遇到问题：
1. 检查浏览器控制台错误（F12 → Console）
2. 查看GitHub Actions日志（Settings → Pages → Build）
3. 搜索错误信息或提问