@echo off
chcp 65001 >nul
echo.
echo ========================================
echo     咖啡网站部署到GitHub指南
echo ========================================
echo.
echo 你有3种方法可以将网站上传到GitHub：
echo.
echo 方法1：网页直接上传（推荐给新手）
echo 方法2：使用Python脚本上传
echo 方法3：安装Git后使用命令行
echo.
echo 请选择：
echo.
echo 1. 我想用网页直接上传（最简单）
echo 2. 我想用Python脚本上传
echo 3. 我想安装Git后用命令行
echo.
set /p choice="请输入数字选择 (1/2/3): "

if "%choice%"=="1" goto method1
if "%choice%"=="2" goto method2
if "%choice%"=="3" goto method3

echo 选择无效
pause
exit

:method1
echo.
echo ========================================
echo     方法1：网页直接上传
echo ========================================
echo.
echo 步骤：
echo 1. 打开浏览器，访问：https://github.com/wyc0229/coffee-website
echo 2. 点击绿色的 "Add file" 按钮
echo 3. 选择 "Upload files"
echo 4. 将这个文件夹中的所有文件拖拽到上传区域：
echo    - index.html
echo    - css/ 文件夹（包含里面的文件）
echo    - js/ 文件夹（包含里面的文件）
echo    - README.md
echo    - DEPLOY_GITHUB.md
echo    - server.py
echo    - start_server.bat
echo 5. 在下方填写：Initial commit: 完整的咖啡品鉴网站
echo 6. 点击 "Commit changes"
echo.
echo 上传完成后：
echo 1. 点击 "Settings" → "Pages"
echo 2. 设置 Source: main branch, / (root)
echo 3. 点击 "Save"
echo 4. 等待几分钟，访问：https://wyc0229.github.io/coffee-website
echo.
pause
exit

:method2
echo.
echo ========================================
echo     方法2：Python脚本上传
echo ========================================
echo.
echo 需要先获取GitHub个人访问令牌：
echo.
echo 获取令牌步骤：
echo 1. 登录GitHub → 点击右上角头像 → Settings
echo 2. 左侧菜单最下方：Developer settings
echo 3. Personal access tokens → Tokens (classic)
echo 4. Generate new token (classic)
echo 5. 填写 Note: "咖啡网站上传"
echo 6. 选择权限：勾选 "repo" (全部)
echo 7. 点击 Generate token
echo 8. 复制生成的令牌（只显示一次，请保存好）
echo.
echo 准备好令牌后，运行：
echo python upload_to_github.py
echo.
pause
exit

:method3
echo.
echo ========================================
echo     方法3：安装Git后使用命令行
echo ========================================
echo.
echo 步骤：
echo 1. 下载安装Git：https://git-scm.com/download/win
echo 2. 安装完成后，在这个文件夹中右键 → Git Bash Here
echo 3. 依次运行以下命令：
echo.
echo    git init
echo    git add .
echo    git commit -m "Initial commit: 完整的咖啡品鉴网站"
echo    git remote add origin https://github.com/wyc0229/coffee-website.git
echo    git branch -M main
echo    git push -u origin main
echo.
echo 4. 输入GitHub用户名和密码（密码处粘贴个人访问令牌）
echo.
echo 完成后，在GitHub网站启用Pages：
echo 1. 访问：https://github.com/wyc0229/coffee-website
echo 2. 点击 Settings → Pages
echo 3. 设置 Source: main branch, / (root)
echo 4. 点击 Save
echo.
pause
exit