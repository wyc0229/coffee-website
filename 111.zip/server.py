#!/usr/bin/env python3
"""
简单的Python HTTP服务器，用于预览咖啡网站
"""

import http.server
import socketserver
import os
import webbrowser
import sys

# 设置端口
PORT = 8000

# 切换到网站目录
os.chdir(os.path.dirname(os.path.abspath(__file__)))

# 创建自定义请求处理器，设置正确的MIME类型
class CustomHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        # 添加CORS头
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        super().end_headers()
    
    def guess_type(self, path):
        # 确保CSS和JS文件有正确的MIME类型
        if path.endswith('.css'):
            return 'text/css'
        elif path.endswith('.js'):
            return 'application/javascript'
        return super().guess_type(path)

def main():
    try:
        # 创建服务器
        with socketserver.TCPServer(("", PORT), CustomHTTPRequestHandler) as httpd:
            print(f"服务器启动在 http://localhost:{PORT}")
            print(f"网站目录: {os.getcwd()}")
            print("按 Ctrl+C 停止服务器")
            
            # 自动打开浏览器
            webbrowser.open(f'http://localhost:{PORT}')
            
            # 启动服务器
            httpd.serve_forever()
            
    except KeyboardInterrupt:
        print("\n服务器已停止")
        sys.exit(0)
    except OSError as e:
        if e.errno == 10048:  # 端口被占用
            print(f"错误: 端口 {PORT} 已被占用，请尝试其他端口")
            print("你可以修改 server.py 中的 PORT 变量")
            sys.exit(1)
        else:
            raise

if __name__ == "__main__":
    main()