// 咖啡网站交互功能

document.addEventListener('DOMContentLoaded', function() {
    // 移动端菜单切换
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            navLinks.classList.toggle('active');
            const icon = this.querySelector('i');
            if (navLinks.classList.contains('active')) {
                icon.classList.remove('fa-bars');
                icon.classList.add('fa-times');
            } else {
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            }
        });
    }
    
    // 平滑滚动
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                // 关闭移动端菜单
                if (navLinks.classList.contains('active')) {
                    navLinks.classList.remove('active');
                    const icon = menuToggle.querySelector('i');
                    icon.classList.remove('fa-times');
                    icon.classList.add('fa-bars');
                }
                
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // 导航栏滚动效果
    window.addEventListener('scroll', function() {
        const navbar = document.querySelector('.navbar');
        if (window.scrollY > 100) {
            navbar.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.1)';
            navbar.style.backgroundColor = 'rgba(255, 255, 255, 0.95)';
        } else {
            navbar.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.1)';
            navbar.style.backgroundColor = 'var(--color-white)';
        }
    });
    
    // 咖啡豆详情数据
    const beanDetails = {
        arabica: {
            name: '阿拉比卡 Arabica',
            origin: '埃塞俄比亚、巴西、哥伦比亚、危地马拉等',
            altitude: '900-2000米',
            processing: '水洗、日晒、蜜处理',
            flavorProfile: '花果香、柑橘酸、巧克力、坚果',
            characteristics: '酸度明亮，口感顺滑，香气复杂',
            bestFor: '手冲、冷萃、单品咖啡',
            score: {
                aroma: 9,
                flavor: 8.5,
                acidity: 9,
                body: 7,
                aftertaste: 8
            }
        },
        robusta: {
            name: '罗布斯塔 Robusta',
            origin: '越南、印度、印度尼西亚、乌干达等',
            altitude: '200-800米',
            processing: '日晒为主',
            flavorProfile: '坚果、巧克力、焦糖、木质香',
            characteristics: '咖啡因含量高，口感浓郁，油脂丰富',
            bestFor: '意式浓缩、拼配咖啡、速溶咖啡',
            score: {
                aroma: 7,
                flavor: 7.5,
                acidity: 5,
                body: 9,
                aftertaste: 7
            }
        },
        liberica: {
            name: '利比里卡 Liberica',
            origin: '菲律宾、马来西亚、西非',
            altitude: '200-600米',
            processing: '日晒',
            flavorProfile: '烟熏、木质香、花香、香料',
            characteristics: '豆形较大，风味独特，口感醇厚',
            bestFor: '传统冲泡、特色咖啡',
            score: {
                aroma: 8,
                flavor: 7,
                acidity: 6,
                body: 8,
                aftertaste: 8
            }
        },
        yirgacheffe: {
            name: '耶加雪菲 Yirgacheffe',
            origin: '埃塞俄比亚耶加雪菲地区',
            altitude: '1700-2200米',
            processing: '水洗、日晒',
            flavorProfile: '柑橘、茉莉花、柠檬、红茶',
            characteristics: '明亮的柑橘酸度，花香明显，茶感余韵',
            bestFor: '手冲、虹吸、冷萃',
            score: {
                aroma: 9.5,
                flavor: 9,
                acidity: 9,
                body: 7,
                aftertaste: 9
            }
        }
    };
    
    // 显示咖啡豆详情
    window.showBeanDetail = function(beanType) {
        const bean = beanDetails[beanType];
        if (!bean) return;
        
        const modalHtml = `
            <div class="modal-overlay" onclick="closeModal()">
                <div class="modal-content" onclick="event.stopPropagation()">
                    <button class="modal-close" onclick="closeModal()">
                        <i class="fas fa-times"></i>
                    </button>
                    
                    <div class="modal-header">
                        <h2>${bean.name}</h2>
                        <p class="modal-subtitle">详细品鉴信息</p>
                    </div>
                    
                    <div class="modal-body">
                        <div class="detail-grid">
                            <div class="detail-section">
                                <h3><i class="fas fa-globe-americas"></i> 产地信息</h3>
                                <p><strong>主要产区：</strong>${bean.origin}</p>
                                <p><strong>海拔高度：</strong>${bean.altitude}</p>
                                <p><strong>处理方式：</strong>${bean.processing}</p>
                            </div>
                            
                            <div class="detail-section">
                                <h3><i class="fas fa-wine-glass-alt"></i> 风味特征</h3>
                                <p><strong>风味描述：</strong>${bean.flavorProfile}</p>
                                <p><strong>特点：</strong>${bean.characteristics}</p>
                                <p><strong>适合冲泡：</strong>${bean.bestFor}</p>
                            </div>
                            
                            <div class="detail-section">
                                <h3><i class="fas fa-chart-bar"></i> 品鉴评分</h3>
                                <div class="score-chart">
                                    ${Object.entries(bean.score).map(([key, value]) => `
                                        <div class="score-item">
                                            <span>${getScoreLabel(key)}</span>
                                            <div class="score-bar">
                                                <div class="score-fill" style="width: ${value * 10}%"></div>
                                            </div>
                                            <span>${value}/10</span>
                                        </div>
                                    `).join('')}
                                </div>
                            </div>
                            
                            <div class="detail-section">
                                <h3><i class="fas fa-lightbulb"></i> 冲泡建议</h3>
                                <ul class="brewing-tips">
                                    <li>研磨粗细：${getGrindSize(beanType)}</li>
                                    <li>建议水温：${getWaterTemp(beanType)}°C</li>
                                    <li>粉水比例：${getRatio(beanType)}</li>
                                    <li>萃取时间：${getBrewTime(beanType)}</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-footer">
                        <button class="btn-primary" onclick="closeModal()">关闭</button>
                    </div>
                </div>
            </div>
        `;
        
        // 创建模态框
        const modalContainer = document.createElement('div');
        modalContainer.innerHTML = modalHtml;
        document.body.appendChild(modalContainer);
        document.body.style.overflow = 'hidden';
        
        // 添加模态框样式
        addModalStyles();
    };
    
    // 关闭模态框
    window.closeModal = function() {
        const modal = document.querySelector('.modal-overlay');
        if (modal) {
            modal.remove();
            document.body.style.overflow = 'auto';
        }
    };
    
    // 辅助函数
    function getScoreLabel(key) {
        const labels = {
            aroma: '香气',
            flavor: '风味',
            acidity: '酸度',
            body: '醇厚度',
            aftertaste: '余韵'
        };
        return labels[key] || key;
    }
    
    function getGrindSize(beanType) {
        const sizes = {
            arabica: '中细研磨',
            robusta: '中粗研磨',
            liberica: '中粗研磨',
            yirgacheffe: '中细研磨'
        };
        return sizes[beanType] || '中研磨';
    }
    
    function getWaterTemp(beanType) {
        const temps = {
            arabica: '90-92',
            robusta: '88-90',
            liberica: '88-90',
            yirgacheffe: '91-93'
        };
        return temps[beanType] || '90-92';
    }
    
    function getRatio(beanType) {
        const ratios = {
            arabica: '1:15',
            robusta: '1:12',
            liberica: '1:13',
            yirgacheffe: '1:16'
        };
        return ratios[beanType] || '1:15';
    }
    
    function getBrewTime(beanType) {
        const times = {
            arabica: '2-3分钟',
            robusta: '25-30秒',
            liberica: '3-4分钟',
            yirgacheffe: '2.5-3.5分钟'
        };
        return times[beanType] || '2-3分钟';
    }
    
    // 添加模态框样式
    function addModalStyles() {
        if (!document.querySelector('#modal-styles')) {
            const style = document.createElement('style');
            style.id = 'modal-styles';
            style.textContent = `
                .modal-overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background-color: rgba(0, 0, 0, 0.7);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    z-index: 2000;
                    padding: 20px;
                    animation: fadeIn 0.3s ease;
                }
                
                .modal-content {
                    background-color: white;
                    border-radius: 16px;
                    max-width: 800px;
                    width: 100%;
                    max-height: 90vh;
                    overflow-y: auto;
                    position: relative;
                    animation: slideUp 0.3s ease;
                }
                
                .modal-close {
                    position: absolute;
                    top: 20px;
                    right: 20px;
                    background: none;
                    border: none;
                    font-size: 1.5rem;
                    color: var(--color-gray);
                    cursor: pointer;
                    width: 40px;
                    height: 40px;
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    transition: all 0.3s ease;
                }
                
                .modal-close:hover {
                    background-color: var(--color-light-gray);
                    color: var(--color-brown);
                }
                
                .modal-header {
                    padding: 40px 40px 20px;
                    border-bottom: 1px solid var(--color-light-gray);
                }
                
                .modal-header h2 {
                    margin: 0;
                    color: var(--color-brown-dark);
                }
                
                .modal-subtitle {
                    color: var(--color-brown-light);
                    margin-top: 5px;
                }
                
                .modal-body {
                    padding: 30px 40px;
                }
                
                .detail-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                    gap: 30px;
                }
                
                .detail-section h3 {
                    display: flex;
                    align-items: center;
                    gap: 10px;
                    margin-bottom: 15px;
                    color: var(--color-brown);
                }
                
                .detail-section p {
                    margin-bottom: 10px;
                    line-height: 1.6;
                }
                
                .brewing-tips {
                    list-style: none;
                    padding: 0;
                }
                
                .brewing-tips li {
                    padding: 8px 0;
                    border-bottom: 1px solid var(--color-light-gray);
                    color: var(--color-gray);
                }
                
                .brewing-tips li:last-child {
                    border-bottom: none;
                }
                
                .score-chart {
                    margin-top: 10px;
                }
                
                .modal-footer {
                    padding: 20px 40px;
                    border-top: 1px solid var(--color-light-gray);
                    text-align: right;
                }
                
                @keyframes fadeIn {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }
                
                @keyframes slideUp {
                    from {
                        opacity: 0;
                        transform: translateY(20px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }
                
                @media (max-width: 768px) {
                    .modal-content {
                        max-height: 95vh;
                    }
                    
                    .modal-header,
                    .modal-body,
                    .modal-footer {
                        padding: 20px;
                    }
                    
                    .detail-grid {
                        grid-template-columns: 1fr;
                    }
                }
            `;
            document.head.appendChild(style);
        }
    }
    
    // 添加滚动动画
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);
    
    // 观察需要动画的元素
    document.querySelectorAll('.bean-card, .process-step, .tasting-card, .tip').forEach(el => {
        observer.observe(el);
    });
    
    // 添加动画样式
    if (!document.querySelector('#animation-styles')) {
        const style = document.createElement('style');
        style.id = 'animation-styles';
        style.textContent = `
            .bean-card,
            .process-step,
            .tasting-card,
            .tip {
                opacity: 0;
                transform: translateY(20px);
                transition: opacity 0.6s ease, transform 0.6s ease;
            }
            
            .bean-card.animate-in,
            .process-step.animate-in,
            .tasting-card.animate-in,
            .tip.animate-in {
                opacity: 1;
                transform: translateY(0);
            }
            
            .bean-card:nth-child(1) { transition-delay: 0.1s; }
            .bean-card:nth-child(2) { transition-delay: 0.2s; }
            .bean-card:nth-child(3) { transition-delay: 0.3s; }
            .bean-card:nth-child(4) { transition-delay: 0.4s; }
            
            .process-step:nth-child(1) { transition-delay: 0.1s; }
            .process-step:nth-child(2) { transition-delay: 0.2s; }
            .process-step:nth-child(3) { transition-delay: 0.3s; }
            
            .tasting-card:nth-child(1) { transition-delay: 0.1s; }
            .tasting-card:nth-child(2) { transition-delay: 0.2s; }
            .tasting-card:nth-child(3) { transition-delay: 0.3s; }
            .tasting-card:nth-child(4) { transition-delay: 0.4s; }
        `;
        document.head.appendChild(style);
    }
});